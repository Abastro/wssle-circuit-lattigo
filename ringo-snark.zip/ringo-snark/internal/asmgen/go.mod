module github.com/sp301415/ringo-snark/internal/asmgen

go 1.21

require github.com/mmcloughlin/avo v0.6.0

require (
	golang.org/x/mod v0.20.0 // indirect
	golang.org/x/sync v0.8.0 // indirect
	golang.org/x/tools v0.24.1 // indirect
)
