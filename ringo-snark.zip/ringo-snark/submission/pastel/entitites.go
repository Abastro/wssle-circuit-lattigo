package pastel

import (
	"math/big"

	"github.com/sp301415/ringo-snark/buckler"
	"github.com/sp301415/ringo-snark/math/bignum"
)

type SecretKeyCircuit[E bignum.Uint[E]] struct {
	NTTChecker buckler.LinearChecker[E]
	Coeffs     buckler.Witness[E]
	NTT        buckler.Witness[E]
}

func (c *SecretKeyCircuit[E]) Define(ctx *buckler.Context[E]) {
	ctx.AddLinearConstraint(c.NTT, c.Coeffs, c.NTTChecker)
	ctx.AddInfNormConstraint(c.Coeffs, 1)
}

type PublicKeyCircuit[E bignum.Uint[E]] struct {
	SecretKeyCircuit[E]

	PublicKeyNTT [2]buckler.PublicWitness[E]

	ErrorCoeffs buckler.Witness[E]
	ErrorNTT    buckler.Witness[E]
}

func (c *PublicKeyCircuit[E]) Define(ctx *buckler.Context[E]) {
	ctx.AddLinearConstraint(c.ErrorNTT, c.ErrorCoeffs, c.SecretKeyCircuit.NTTChecker)

	ctx.AddInfNormConstraint(c.ErrorCoeffs, 20)

	var pkConstraint buckler.ArithmeticConstraint[E]
	pkConstraint.AddTerm(c.PublicKeyNTT[0])
	pkConstraint.AddTerm(c.PublicKeyNTT[1], c.SecretKeyCircuit.NTT)
	pkConstraint.SubTerm(nil, c.ErrorNTT)
	ctx.AddArithmeticConstraint(pkConstraint)
}

type RegisterCircuit[E bignum.Uint[E]] struct {
	NTTChecker buckler.LinearChecker[E]
	Delta      E
	Gadget     []E

	PublicKeyNTT   [2]buckler.PublicWitness[E]
	CiphertextHNTT [2]buckler.PublicWitness[E]
	CiphertextRNTT [2][][2]buckler.PublicWitness[E]

	MessageHCoeffs buckler.Witness[E]
	MessageHNTT    buckler.Witness[E]
	MessageRCoeffs buckler.Witness[E]
	MessageRNTT    buckler.Witness[E]

	AuxKeyHCoeffs buckler.Witness[E]
	AuxKeyHNTT    buckler.Witness[E]
	AuxKeyRCoeffs [2][]buckler.Witness[E]
	AuxKeyRNTT    [2][]buckler.Witness[E]

	ErrorHCoeffs [2]buckler.Witness[E]
	ErrorHNTT    [2]buckler.Witness[E]
	ErrorRCoeffs [2][][2]buckler.Witness[E]
	ErrorRNTT    [2][][2]buckler.Witness[E]

	CommitmentChecker buckler.LinearChecker[E]
	MonomialChecker   buckler.LinearChecker[E]
}

func (c *RegisterCircuit[E]) Define(ctx *buckler.Context[E]) {
	ctx.AddLinearConstraint(c.MessageHNTT, c.MessageHCoeffs, c.NTTChecker)
	ctx.AddLinearConstraint(c.MessageRNTT, c.MessageRCoeffs, c.NTTChecker)
	ctx.AddLinearConstraint(c.AuxKeyHNTT, c.AuxKeyHCoeffs, c.NTTChecker)
	ctx.AddInfNormConstraint(c.AuxKeyHCoeffs, 1)

	var z E
	negDelta := z.New().Neg(c.Delta)
	for i := range 2 {
		ctx.AddLinearConstraint(c.ErrorHNTT[i], c.ErrorHCoeffs[i], c.NTTChecker)
		ctx.AddInfNormConstraint(c.ErrorHCoeffs[i], 20)

		var ctConstraint buckler.ArithmeticConstraint[E]
		ctConstraint.AddTerm(c.CiphertextHNTT[i])
		ctConstraint.SubTerm(c.PublicKeyNTT[i], c.AuxKeyHNTT)
		ctConstraint.SubTerm(nil, c.ErrorHNTT[i])
		if i == 0 {
			ctConstraint.AddTermWithConst(negDelta, nil, c.MessageHNTT)
		}
		ctx.AddArithmeticConstraint(ctConstraint)
	}

	for r := range 2 {
		for j, gadget := range c.Gadget {
			ctx.AddLinearConstraint(c.AuxKeyRNTT[r][j], c.AuxKeyRCoeffs[r][j], c.NTTChecker)
			ctx.AddInfNormConstraint(c.AuxKeyRCoeffs[r][j], 1)

			negGadget := z.New().Neg(gadget)
			for i := range 2 {
				ctx.AddLinearConstraint(c.ErrorRNTT[r][j][i], c.ErrorRCoeffs[r][j][i], c.NTTChecker)
				ctx.AddInfNormConstraint(c.ErrorRCoeffs[r][j][i], 20)

				var ctConstraint buckler.ArithmeticConstraint[E]
				ctConstraint.AddTerm(c.CiphertextRNTT[r][j][i])
				ctConstraint.SubTerm(c.PublicKeyNTT[i], c.AuxKeyRNTT[r][j])
				ctConstraint.SubTerm(nil, c.ErrorRNTT[r][j][i])
				if i == r {
					ctConstraint.AddTermWithConst(negGadget, nil, c.MessageRNTT)
				}
				ctx.AddArithmeticConstraint(ctConstraint)
			}
		}
	}

	ctx.AddLinearConstraint(c.MessageHCoeffs, c.MessageHCoeffs, c.CommitmentChecker)
	ctx.AddLinearConstraint(c.MessageRCoeffs, c.MessageRCoeffs, c.MonomialChecker)

	ctx.AddInfNormConstraint(c.MessageRCoeffs, 1)

	var monomialConstraint buckler.ArithmeticConstraint[E]
	monomialConstraint.AddTerm(nil, c.MessageRCoeffs, c.MessageRCoeffs)
	ctx.AddSumCheckConstraint(monomialConstraint, 1)
}

func EmptyRegisterCircuit[E bignum.Uint[E]](rank int, delta E, gadget []E, fragments int, totalWt uint64) RegisterCircuit[E] {
	fragmentStride := rank / fragments
	c := RegisterCircuit[E]{
		NTTChecker: buckler.NewNTTChecker[E](rank),
		Delta:      delta,
		Gadget:     gadget,

		CommitmentChecker: &coefficientSupportChecker[E]{
			stride: fragmentStride,
			count:  fragments,
		},
		MonomialChecker: &coefficientSupportChecker[E]{
			stride: fragmentStride / int(totalWt),
			count:  fragments * int(totalWt),
		},
	}
	for r := range 2 {
		c.CiphertextRNTT[r] = make([][2]buckler.PublicWitness[E], len(gadget))
		c.AuxKeyRCoeffs[r] = make([]buckler.Witness[E], len(gadget))
		c.AuxKeyRNTT[r] = make([]buckler.Witness[E], len(gadget))
		c.ErrorRCoeffs[r] = make([][2]buckler.Witness[E], len(gadget))
		c.ErrorRNTT[r] = make([][2]buckler.Witness[E], len(gadget))
	}
	return c
}

// coefficientSupportChecker projects onto count coefficients spaced by stride.
// Its matrix is diagonal, so the transpose is the same projection.
type coefficientSupportChecker[E bignum.Uint[E]] struct {
	stride int
	count  int
}

func (c *coefficientSupportChecker[E]) TransformTo(vOut, v []E) {
	for i := range vOut {
		if i%c.stride == 0 && i/c.stride < c.count {
			vOut[i].Set(v[i])
		} else {
			vOut[i].SetUint64(0)
		}
	}
}

func (c *coefficientSupportChecker[E]) TransposeTo(vOut, v []E) {
	c.TransformTo(vOut, v)
}

type DecryptionCircuit[E bignum.Uint[E]] struct {
	Degree     int
	FloodBound uint64

	PublicKeyCircuit[E]

	MaskNTT    buckler.PublicWitness[E]
	DecMaskNTT buckler.PublicWitness[E]
	BodyNTT    buckler.PublicWitness[E]

	AuxKeyCoeffs buckler.Witness[E]
	AuxKeyNTT    buckler.Witness[E]

	ErrorCoeffs buckler.Witness[E]
	ErrorNTT    buckler.Witness[E]

	QuoCoeffs buckler.Witness[E]
	QuoNTT    buckler.Witness[E]
}

func (c *DecryptionCircuit[E]) Define(ctx *buckler.Context[E]) {
	c.PublicKeyCircuit.Define(ctx)

	ctx.AddLinearConstraint(c.AuxKeyNTT, c.AuxKeyCoeffs, c.SecretKeyCircuit.NTTChecker)
	ctx.AddLinearConstraint(c.ErrorNTT, c.ErrorCoeffs, c.SecretKeyCircuit.NTTChecker)
	ctx.AddLinearConstraint(c.QuoNTT, c.QuoCoeffs, c.SecretKeyCircuit.NTTChecker)

	ctx.AddInfNormConstraint(c.AuxKeyCoeffs, 1)
	ctx.AddInfNormConstraint(c.ErrorCoeffs, 1)
	ctx.AddInfNormConstraint(c.QuoCoeffs, uint64(1*(c.Degree+1)))

	var z E
	flood := z.New().SetBigInt(new(big.Int).Lsh(big.NewInt(1), uint(c.FloodBound)))

	var ddecConstraint buckler.ArithmeticConstraint[E]
	ddecConstraint.AddTerm(c.BodyNTT)
	ddecConstraint.SubTerm(c.MaskNTT, c.SecretKeyCircuit.NTT)
	ddecConstraint.SubTerm(c.DecMaskNTT, c.AuxKeyNTT)
	ddecConstraint.SubTerm(nil, c.ErrorNTT)
	ddecConstraint.AddTermWithConst(flood, nil, c.QuoNTT)
	ctx.AddArithmeticConstraint(ddecConstraint)
}

func EmptyDecCircuit[E bignum.Uint[E]](rank int, floodBound uint64) DecryptionCircuit[E] {
	return DecryptionCircuit[E]{
		PublicKeyCircuit: PublicKeyCircuit[E]{
			SecretKeyCircuit: SecretKeyCircuit[E]{
				NTTChecker: buckler.NewNTTChecker[E](rank),
			},
		},

		Degree:     rank,
		FloodBound: floodBound,
	}
}
