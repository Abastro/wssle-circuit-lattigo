package pastel

import (
	crand "crypto/rand"
	"math/big"
	"math/rand/v2"

	"github.com/sp301415/ringo-snark/buckler"
	"github.com/sp301415/ringo-snark/math/bignum"
	"github.com/sp301415/ringo-snark/math/bigpoly"
	"github.com/sp301415/ringo-snark/math/csprng"
)

type KeyGenerator[E bignum.Uint[E]] struct {
	Op *bigpoly.CyclotomicOperator[E]

	Gadget []E

	UniformSampler  *csprng.UniformSampler
	GaussianSampler *csprng.RoundedGaussianSampler
}

func NewKeyGenerator[E bignum.Uint[E]](rank int, gadLen int) *KeyGenerator[E] {
	// Emulate Gadget
	gadget := make([]E, gadLen)
	for i := range gadget {
		gadget[i] = gadget[i].New().SetUint64(rand.Uint64N(1 << 60))
	}

	return &KeyGenerator[E]{
		Op:              bigpoly.NewCyclotomicOperator[E](rank),
		Gadget:          gadget,
		UniformSampler:  csprng.NewUniformSampler(),
		GaussianSampler: csprng.NewRoundedGaussianSampler(),
	}
}

func (kg *KeyGenerator[E]) GenSecretKey() SecretKeyCircuit[E] {
	sk := kg.Op.NewPoly(false)
	for i := range sk.Rank() {
		sk.Coeffs[i].SetInt64(int64(kg.UniformSampler.Sample()) % 2)
	}
	skNTT := kg.Op.FwdNTT(sk)

	return SecretKeyCircuit[E]{
		NTTChecker: buckler.NewNTTChecker[E](kg.Op.Rank()),
		Coeffs:     sk.Coeffs,
		NTT:        skNTT.Coeffs,
	}
}

func (kg *KeyGenerator[E]) GenPublicKey(sk SecretKeyCircuit[E]) PublicKeyCircuit[E] {
	maskNTT := kg.Op.NewPoly(true)
	for i := 0; i < kg.Op.Rank(); i++ {
		maskNTT.Coeffs[i].MustSetRandom()
	}

	errCoeffs := kg.Op.NewPoly(false)
	for i := 0; i < kg.Op.Rank(); i++ {
		errCoeffs.Coeffs[i].SetInt64(kg.GaussianSampler.Sample(0, 3.2))
	}
	errNTT := kg.Op.FwdNTT(errCoeffs)

	bodyNTT := kg.Op.NewPoly(true)
	kg.Op.MulSubTo(bodyNTT, maskNTT, &bigpoly.Poly[E]{Coeffs: sk.NTT, IsNTT: true})
	kg.Op.AddTo(bodyNTT, bodyNTT, errNTT)

	return PublicKeyCircuit[E]{
		SecretKeyCircuit: sk,

		PublicKeyNTT: [2]buckler.PublicWitness[E]{
			bodyNTT.Coeffs,
			maskNTT.Coeffs,
		},

		ErrorCoeffs: errCoeffs.Coeffs,
		ErrorNTT:    errNTT.Coeffs,
	}
}

// GenRegister encrypts a fresh 128-bit commitment with the given delta scale.
// fragments must divide 128; each fragment contains 128/fragments bits.
// totalWt must be a positive divisor of the ring rank divided by fragments.
// The rotation message is X^(stride*r), with r in [0, fragments*totalWt)
// and stride = rank / (fragments*totalWt).
func (kg *KeyGenerator[E]) GenRegister(pk PublicKeyCircuit[E], delta E, fragments int, totalWt uint64) RegisterCircuit[E] {
	const (
		errBound       = 20
		commitmentBits = 128
	)
	if fragments <= 0 || commitmentBits%fragments != 0 {
		panic("GenRegister: fragments must be a positive divisor of 128")
	}
	fragmentBits := uint(commitmentBits / fragments)

	c := EmptyRegisterCircuit(kg.Op.Rank(), delta, kg.Gadget, fragments, totalWt)
	c.PublicKeyNTT = pk.PublicKeyNTT
	commitment, _ := crand.Int(kg.UniformSampler, new(big.Int).Lsh(big.NewInt(1), commitmentBits))

	msgH := kg.Op.NewPoly(false)
	remaining := new(big.Int).Set(commitment)
	fragmentMask := new(big.Int).Lsh(big.NewInt(1), fragmentBits)
	fragmentMask.Sub(fragmentMask, big.NewInt(1))
	fragment := new(big.Int)
	for k := range fragments {
		fragment.And(remaining, fragmentMask)
		fragment.Add(fragment, big.NewInt(1))
		msgH.Coeffs[k*(kg.Op.Rank()/fragments)].SetBigInt(fragment)
		remaining.Rsh(remaining, fragmentBits)
	}
	msgHNTT := kg.Op.FwdNTT(msgH)

	r := kg.UniformSampler.SampleN(uint64(fragments) * totalWt)
	stride := (kg.Op.Rank() / fragments) / int(totalWt)
	msgR := kg.Op.NewPoly(false)
	msgR.Coeffs[stride*int(r)].SetUint64(1)
	msgRNTT := kg.Op.FwdNTT(msgR)

	encryptZero := func(ciphertextNTT *[2]buckler.PublicWitness[E], auxKeyCoeffs, auxKeyNTT *buckler.Witness[E], errorCoeffs, errorNTT *[2]buckler.Witness[E]) {
		aux := kg.Op.NewPoly(false)
		for i := range kg.Op.Rank() {
			aux.Coeffs[i].SetInt64(int64(kg.UniformSampler.Sample()) % 2)
		}
		auxNTT := kg.Op.FwdNTT(aux)
		*auxKeyCoeffs, *auxKeyNTT = aux.Coeffs, auxNTT.Coeffs

		for i := range 2 {
			noise := kg.Op.NewPoly(false)
			for j := range kg.Op.Rank() {
				e := kg.GaussianSampler.Sample(0, 3.2)
				for e < -errBound || e > errBound {
					e = kg.GaussianSampler.Sample(0, 3.2)
				}
				noise.Coeffs[j].SetInt64(e)
			}
			noiseNTT := kg.Op.FwdNTT(noise)
			errorCoeffs[i], errorNTT[i] = noise.Coeffs, noiseNTT.Coeffs

			ct := kg.Op.Mul(&bigpoly.Poly[E]{Coeffs: pk.PublicKeyNTT[i], IsNTT: true}, auxNTT)
			kg.Op.AddTo(ct, ct, noiseNTT)
			ciphertextNTT[i] = ct.Coeffs
		}
	}

	encryptZero(&c.CiphertextHNTT, &c.AuxKeyHCoeffs, &c.AuxKeyHNTT, &c.ErrorHCoeffs, &c.ErrorHNTT)
	c.MessageHCoeffs, c.MessageHNTT = msgH.Coeffs, msgHNTT.Coeffs
	kg.Op.ScalarMulAddTo(&bigpoly.Poly[E]{Coeffs: c.CiphertextHNTT[0], IsNTT: true}, msgHNTT, delta)

	c.MessageRCoeffs, c.MessageRNTT = msgR.Coeffs, msgRNTT.Coeffs
	for row := range 2 {
		for j, gadget := range kg.Gadget {
			encryptZero(&c.CiphertextRNTT[row][j], &c.AuxKeyRCoeffs[row][j], &c.AuxKeyRNTT[row][j], &c.ErrorRCoeffs[row][j], &c.ErrorRNTT[row][j])
			kg.Op.ScalarMulAddTo(&bigpoly.Poly[E]{Coeffs: c.CiphertextRNTT[row][j][row], IsNTT: true}, msgRNTT, gadget)
		}
	}
	return c
}

// GenDecryption generates a decryption circuit for a ciphertext mask in NTT form.
// floodBound is the base-2 logarithm of the decryption masking bound.
func (kg *KeyGenerator[E]) GenDecryption(sk SecretKeyCircuit[E], pk PublicKeyCircuit[E], ctMaskNTT []E, floodBound uint64) DecryptionCircuit[E] {
	maskNTT := &bigpoly.Poly[E]{Coeffs: ctMaskNTT, IsNTT: true}
	skNTT := &bigpoly.Poly[E]{Coeffs: sk.NTT, IsNTT: true}

	decMaskCoeffs := kg.Op.NewPoly(false)
	decBound := new(big.Int).Lsh(big.NewInt(1), uint(floodBound))
	for i := 0; i < kg.Op.Rank(); i++ {
		c, _ := crand.Int(kg.UniformSampler, decBound)
		decMaskCoeffs.Coeffs[i].SetBigInt(c)
	}
	decMaskNTT := kg.Op.FwdNTT(decMaskCoeffs)

	auxKeyCoeffs := kg.Op.NewPoly(false)
	for i := 0; i < kg.Op.Rank(); i++ {
		auxKeyCoeffs.Coeffs[i].SetInt64(int64(kg.UniformSampler.Sample()) % 2)
	}
	auxKeyNTT := kg.Op.FwdNTT(auxKeyCoeffs)

	errCoeffs := kg.Op.NewPoly(false)
	for i := 0; i < kg.Op.Rank(); i++ {
		errCoeffs.Coeffs[i].SetInt64(int64(kg.UniformSampler.Sample()) % 2)
	}
	errNTT := kg.Op.FwdNTT(errCoeffs)

	errFullNTT := kg.Op.NewPoly(true)
	kg.Op.MulTo(errFullNTT, decMaskNTT, auxKeyNTT)
	kg.Op.AddTo(errFullNTT, errNTT, errFullNTT)
	errFullCoeffs := kg.Op.InvNTT(errFullNTT)

	quoCoeffs, remCoeffs := kg.Op.NewPoly(false), kg.Op.NewPoly(false)
	var z E
	q := z.New().SetInt64(-1).BigInt(new(big.Int))
	q.Add(q, big.NewInt(1))
	qHalf := new(big.Int).Rsh(q, 1)
	c, quo, rem := new(big.Int), new(big.Int), new(big.Int)
	for i := 0; i < kg.Op.Rank(); i++ {
		// Center the coefficient before computing the signed quotient.
		errFullCoeffs.Coeffs[i].BigInt(c)
		if c.Cmp(qHalf) > 0 {
			c.Sub(c, q)
		}
		quo.DivMod(c, decBound, rem)
		quoCoeffs.Coeffs[i].SetBigInt(quo)
		remCoeffs.Coeffs[i].SetBigInt(rem)
	}
	quoNTT, remNTT := kg.Op.FwdNTT(quoCoeffs), kg.Op.FwdNTT(remCoeffs)

	bodyNTT := kg.Op.NewPoly(true)
	kg.Op.MulTo(bodyNTT, maskNTT, skNTT)
	kg.Op.AddTo(bodyNTT, bodyNTT, remNTT)

	return DecryptionCircuit[E]{
		Degree:     kg.Op.Rank(),
		FloodBound: floodBound,

		PublicKeyCircuit: pk,

		MaskNTT:    maskNTT.Coeffs,
		DecMaskNTT: decMaskNTT.Coeffs,
		BodyNTT:    bodyNTT.Coeffs,

		AuxKeyCoeffs: auxKeyCoeffs.Coeffs,
		AuxKeyNTT:    auxKeyNTT.Coeffs,

		ErrorCoeffs: errCoeffs.Coeffs,
		ErrorNTT:    errNTT.Coeffs,

		QuoCoeffs: quoCoeffs.Coeffs,
		QuoNTT:    quoNTT.Coeffs,
	}
}
