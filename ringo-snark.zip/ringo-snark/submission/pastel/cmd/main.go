package main

import (
	"flag"
	"fmt"
	"math"
	"math/big"
	"time"

	"github.com/sp301415/ringo-snark/buckler"
	"github.com/sp301415/ringo-snark/math/bignum"
	"github.com/sp301415/ringo-snark/submission/pastel"
	"github.com/sp301415/ringo-snark/submission/pastel/zp132"
	"github.com/sp301415/ringo-snark/submission/pastel/zp159"
	"github.com/sp301415/ringo-snark/submission/pastel/zp209"
	"github.com/sp301415/ringo-snark/submission/pastel/zp210"
	"github.com/sp301415/ringo-snark/submission/pastel/zp236"
	"github.com/sp301415/ringo-snark/submission/pastel/zp416"
)

var (
	paramsFlag = flag.Int("params", 0, "Parameter Set")
)

func main() {
	flag.Parse()

	switch *paramsFlag {
	case 0:
		run[*zp416.Uint, *zp236.Uint](1<<14, 2, 1, 106, 80)
	case 1:
		run[*zp210.Uint, *zp159.Uint](1<<13, 4, 2, 93, 78)
	case 2:
		run[*zp209.Uint, *zp132.Uint](1<<13, 2, 4, 97, 78)
	default:
		panic("unrecognized parameters")
	}
}

func run[PQ bignum.Uint[PQ], Q bignum.Uint[Q]](rank, gadLen, fragments, logDelta, logFlood int) {
	totalWt := uint64(rank / fragments)
	var z PQ
	delta := z.New().SetBigInt(new(big.Int).Lsh(big.NewInt(1), uint(logDelta)))
	kgQ := pastel.NewKeyGenerator[Q](rank, gadLen)
	kgPQ := pastel.NewKeyGenerator[PQ](rank, gadLen)

	skPQ := kgPQ.GenSecretKey()
	pkPQ := kgPQ.GenPublicKey(skPQ)
	reg := kgPQ.GenRegister(pkPQ, delta, fragments, totalWt)

	cReg := pastel.EmptyRegisterCircuit(rank, delta, kgPQ.Gadget, fragments, totalWt)
	prvReg, vrfReg, err := buckler.Compile(rank, &cReg, nil)
	if err != nil {
		panic(err)
	}

	now := time.Now()
	pfReg, err := prvReg.Prove(&reg)
	fmt.Println("Reg Prove:", time.Since(now))
	if err != nil {
		panic(err)
	}

	now = time.Now()
	okReg := vrfReg.Verify(&reg, pfReg)
	fmt.Println("Reg Verify:", time.Since(now))
	fmt.Println("Reg Verify Result:", okReg)
	fmt.Println("Reg Proof Size", vrfReg.JindoParams.Size()/math.Exp2(23), "MiB")

	skQ := kgQ.GenSecretKey()
	pkQ := kgQ.GenPublicKey(skQ)

	ctMaskNTT := make([]Q, rank)
	for i := range rank {
		ctMaskNTT[i] = ctMaskNTT[i].New().MustSetRandom()
	}

	dec := kgQ.GenDecryption(skQ, pkQ, ctMaskNTT, uint64(logFlood))

	cDec := pastel.EmptyDecCircuit[Q](rank, uint64(logFlood))
	prvDec, vrfDec, err := buckler.Compile(rank, &cDec, nil)
	if err != nil {
		panic(err)
	}

	now = time.Now()
	pfDec, err := prvDec.Prove(&dec)
	fmt.Println("DDec Prove:", time.Since(now))
	if err != nil {
		panic(err)
	}

	now = time.Now()
	okDec := vrfDec.Verify(&dec, pfDec)
	fmt.Println("DDec Verify:", time.Since(now))
	fmt.Println("DDec Verify Result:", okDec)
	fmt.Println("DDec Proof Size:", vrfDec.JindoParams.Size()/math.Exp2(23), "MiB")
}
